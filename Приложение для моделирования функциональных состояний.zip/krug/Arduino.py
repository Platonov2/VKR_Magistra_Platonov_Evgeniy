import serial
import pandas
import time


# Класс для считывания данных с ардуино
class Arduino:
    def __init__(self):
        self.ecg = []
        self.fpg = []
        self.gsr = []

        self.leftErrors = []
        self.centreErrors = []
        self.rightErrors = []

        self.time = []

        self.ser = serial.Serial("COM9", 9600)
        self.isRecording = False

    def startDevice(self, pipeConnection):

        while True:
            if self.isRecording:
                data = self.ser.readline().decode("utf-8").split(" ")

                try:
                    ecg = data[0].split(":")[1]
                    fpg = data[1].split(":")[1]
                    gsr = data[2].split(":")[1]
                except:
                    print(data)
                    continue

                self.ecg.append(ecg)
                self.fpg.append(fpg)
                self.gsr.append(gsr)

                self.leftErrors.append(0)
                self.centreErrors.append(0)
                self.rightErrors.append(0)

                self.time.append(int(round(time.time() * 1000)))

            if pipeConnection.poll():
                message = pipeConnection.recv()

                if message == "start":
                    self.isRecording = True
                elif message == "end":
                    self.isRecording = False

                    dataFrame = pandas.DataFrame()

                    dataFrame["time"] = self.time
                    dataFrame["ecg"] = self.ecg
                    dataFrame["fpg"] = self.fpg
                    dataFrame["gsr"] = self.gsr
                    dataFrame["leftErrors"] = self.leftErrors
                    dataFrame["centreErrors"] = self.centreErrors
                    dataFrame["rightErrors"] = self.rightErrors

                    dataFrame.to_csv("data/last.csv")
                elif self.isRecording:
                    circleName = message.split(' ')[0]
                    error = message.split(' ')[1]

                    if circleName == "left":
                        print("left")
                        self.leftErrors[len(self.leftErrors) - 1] = error
                    elif circleName == "centre":
                        print("centre")
                        self.centreErrors[len(self.centreErrors) - 1] = error
                    elif circleName == "right":
                        print("right")
                        self.rightErrors[len(self.rightErrors) - 1] = error

    def startRecord(self):
        self.isRecording = True
