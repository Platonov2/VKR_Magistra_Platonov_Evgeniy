import random
import pygame
from Circle import Circle


class Level:
    def __init__(self, connection, screen, width, speeds, minSpeeds, maxSpeeds):
        self.connection = connection
        self.screen = screen
        self.width = width

        # Создание кругов
        leftAngle = random.randint(0, 120)
        self.leftCircle = Circle(screen, 'images/track.svg', 'images/sharik.svg', (width * (1 / 5), 300), leftAngle,
                                 speeds[0], minSpeeds[0], maxSpeeds[0], 'Cb4', 'Cb1', connection, "left")
        centreAngle = random.randint(120, 240)
        self.centreCircle = Circle(screen, 'images/track.svg', 'images/sharik.svg', (width / 2, 550), centreAngle,
                                   speeds[1], minSpeeds[1], maxSpeeds[1], 'Db4', 'Db1', connection, "centre")
        rightAngle = random.randint(240, 360)
        self.rightCircle = Circle(screen, 'images/track.svg', 'images/sharik.svg', (width * (4 / 5), 300), rightAngle,
                                  speeds[2], minSpeeds[2], maxSpeeds[2], 'Eb4', 'Eb1', connection, "right")

        self.maxTime = 72000
        self.timerOffset = 0

    # Отрисовка кругов
    def draw(self):
        self.timerOffset += self.width / self.maxTime

        self.screen.fill((255, 255, 255))

        pygame.draw.rect(self.screen, pygame.Color("Blue"), (self.width * -1 + self.timerOffset, 0, self.width, 20))

        self.leftCircle.update()
        self.centreCircle.update()
        self.rightCircle.update()

    # Обработка кнопок QWE
    def keyHandler(self, key):
        # Левый круг
        # if key == pygame.K_q:
        if key == pygame.K_KP4:
            self.leftCircle.sharikClick()
        # Центральный круг
        # if key == pygame.K_w:
        if key == pygame.K_KP5:
            self.centreCircle.sharikClick()
        # Правый круг
        # if key == pygame.K_e:
        if key == pygame.K_KP6:
            self.rightCircle.sharikClick()
