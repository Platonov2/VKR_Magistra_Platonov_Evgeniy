import time
import pygame
from Level import Level

def start(connection):
    pygame.init()

    width = 1536
    height = 864

    screen = pygame.display.set_mode((width, height))

    normalLevel = Level(connection, screen, width, [1.5, 2, 2.5], [2.5, 3, 3.5], [3.5, 4, 4.5])
    stressLevel = Level(connection, screen, width, [1.5, 2, 2.5], [6, 7, 8], [6, 7, 8])
    monotonyLevel = Level(connection, screen, width, [2, 2.5, 3], [0.5, 1, 1.5], [1, 1.5, 2])
    game = Game(screen, width, normalLevel, stressLevel, monotonyLevel, connection)

    clock = pygame.time.Clock()
    running = True
    while running:

        for event in pygame.event.get():
            # if event.type == pygame.QUIT:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    connection.send("end")
                if game.isMenu:
                    game.menuKeyHandler(event.key)
                if game.isNormalLevel:
                    game.normalLevel.keyHandler(event.key)
                if game.isStressLevel:
                    game.stressLevel.keyHandler(event.key)
                if game.isMonotonyLevel:
                    game.monotonyLevel.keyHandler(event.key)

        if game.isMenu:
            game.draw()
        if game.isNormalLevel:
            game.normalLevel.draw()
        if game.isStressLevel:
            game.stressLevel.draw()
        if game.isMonotonyLevel:
            game.monotonyLevel.draw()

        pygame.display.update()
        screen.fill((255, 255, 255))
        # Игра работает в 60 fps
        clock.tick(60)

    pygame.quit()

# Класс игры (хотя похоже только на меню, но и так норм)
class Game:
    def __init__(self, screen, width, normalLevel, stressLevel, monotonyLevel, connection):
        self.screen = screen
        self.width = width
        self.font = pygame.font.SysFont(None, 64)
        self.connection = connection

        self.normalLevel = normalLevel
        self.stressLevel = stressLevel
        self.monotonyLevel = monotonyLevel

        # Флаги текущего режима
        self.isMenu = True
        self.isNormalLevel = False
        self.isStressLevel = False
        self.isMonotonyLevel = False

    # Отрисовка текста меню
    def draw(self):
        text = self.font.render("1 - Нормальный режим", True, (90, 90, 90))
        text_rect = text.get_rect(center=(self.width * (1 / 5), 300))
        self.screen.blit(text, text_rect)

        text = self.font.render("2 - Режим напряжения", True, (90, 90, 90))
        text_rect = text.get_rect(center=(self.width / 2, 550))
        self.screen.blit(text, text_rect)

        text = self.font.render("3 - Режим монотонии", True, (90, 90, 90))
        text_rect = text.get_rect(center=(self.width * (4 / 5), 300))
        self.screen.blit(text, text_rect)

    # Обработка клавиш для выбора режима
    def menuKeyHandler(self, key):
        # Нормальный режим
        if key == pygame.K_1:
            self.isMenu = False
            self.isNormalLevel = True
            self.normalLevel.draw()
            pygame.display.update()
            self.connection.send("start")
            time.sleep(3)
        # Режим напряжения
        if key == pygame.K_2:
            self.isMenu = False
            self.isStressLevel = True
            self.stressLevel.draw()
            pygame.display.update()
            self.connection.send("start")
            time.sleep(3)
        # Режим монотонии
        if key == pygame.K_3:
            self.isMenu = False
            self.isMonotonyLevel = True
            self.monotonyLevel.draw()
            pygame.display.update()
            self.connection.send("start")
            time.sleep(3)
