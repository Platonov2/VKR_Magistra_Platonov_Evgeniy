import random
import statistics

import pygame
from pgzero import tone


class Circle:
    def __init__(self, screen, trackSprite, sharikSprite, position, startAngle, speed, minSpeed, maxSpeed, goodBeepTone, badBeepTone, connection, name):
        # Объект круга
        self.track = pygame.image.load(trackSprite)
        self.track.convert()
        self.trackRect = self.track.get_rect()
        self.trackRect.center = position
        # Объект шарика
        self.sharik = pygame.image.load(sharikSprite)
        self.sharik.convert()
        self.sharikRect = self.sharik.get_rect()
        self.sharikRect.center = position

        # Минимальный угол от начала координат до метки на круге
        minAngle = (startAngle + 180) % 360 - 180
        # У каждого круга индивидуальное смещение метки (необходимо для разнообразия; чтобы метки не находились в начале координат)
        self.trackAngle = minAngle + 180
        # Случайное начальное положение шарика (необходимо для предотвращения наложения фаз разных кругов)
        self.sharikAngle = random.randint(0, 90) + 180
        self.speed = speed
        self.screen = screen
        self.position = position

        self.font = pygame.font.SysFont(None, 64)
        # Тона звуков задаются буквеной записью ноты и октавы
        self.goodTone = tone.create(goodBeepTone, 0.1)
        self.badTone = tone.create(badBeepTone, 0.1)

        # Текущая точность
        self.currentAccuracy = 0
        # Массив углов отклонений со знаком смещения от метки (это цель исследования)
        self.errors = []
        # Массив точностей (то же, что и отклонения, но в процентном соотношении)
        self.accuracies = []
        # Флаг первого круга (необходим для корректного расчёта ошибки на первом круге)
        self.isFirstLap = True
        # Флаг нажатия кнопки на текущем круге
        #     (если пользователь не нажал кнопку, то при прохождении через диаметрально противоположную точку от метки,
        #      будет начислено пенальти за пропуск в размере наихудшего варианта с отклонением в 180 градусов)
        #     (также запрещено нажимать кнопку более одного раза за круг)
        self.isClickLastLap = False
        # Соединение с ардуино через pipe (необходим для отправки точностей нажатий)
        self.connection = connection
        # Название круга
        self.name = name

        # Флаг увеличения или уменьшения скорости
        self.isAccelerate = True
        self.minSpeed = minSpeed
        self.maxSpeed = maxSpeed

        self.frameId = 0

    def update(self):
        self.frameId += 1

        self.draw()

        # Движение шарика реализовано путём изменения угла наклона его спрайта (для подробностей см. svg)
        self.sharikAngle += self.speed

        # Скорость изменяется от текущей до максимальной, а потом назад до минимальной
        if self.speed >= self.maxSpeed:
            print(self.frameId)
            self.isAccelerate = False
        if self.speed <= self.minSpeed:
            self.isAccelerate = True

        if self.isAccelerate:
            self.speed += 0.00005
        else:
            self.speed -= 0.00005

        # Pygame не отслеживает переполнение угла через 360 градусов. Приходится делать это вручную
        if self.sharikAngle > 360 + self.trackAngle:
            self.sharikAngle -= 360

        # При проходе шарика через диаметрально противоположную точку от метки...
        if 180 + self.trackAngle - self.speed / 2 < self.sharikAngle < 180 + self.trackAngle + self.speed / 2:
            # ...если пользователь забыл нажать кнопку...
            if not self.isClickLastLap and not self.isFirstLap:
                # ...накладывается пенальти с наихудшей точностью за круг...
                self.calculateAccuracy(180 + self.trackAngle)
            self.newLap()

    def draw(self):
        # Отрисовка точности круга
        text = self.font.render(str(self.currentAccuracy), True, (90, 90, 90))
        text_rect = text.get_rect(center=(self.position[0], self.position[1]))
        self.screen.blit(text, text_rect)
        # Отрисовка тени для красивости
        textShadow = self.font.render(str(self.currentAccuracy), True, (180, 180, 180))
        textShadowRect = text.get_rect(center=(self.position[0] - 1, self.position[1] - 1))
        self.screen.blit(textShadow, textShadowRect)

        # Отрисовка движения шарика
        self.blitRotate(self.screen, self.track, self.trackRect.center,
                        (self.track.get_size()[0] / 2, self.track.get_size()[1] / 2), self.trackAngle)
        self.blitRotate(self.screen, self.sharik, self.sharikRect.center,
                        (self.track.get_size()[0] / 2, self.track.get_size()[1] / 2), self.sharikAngle)

    def newLap(self):
        self.isFirstLap = False
        self.isClickLastLap = False

    # Метод перерасчёта точности и заполнения целевых массивов
    def calculateAccuracy(self, sharikAngle):
        self.isClickLastLap = True

        # Шарик на спрайте находится не по центру, так что для визуального выравнивания вычитается единица
        angleDiff = sharikAngle - self.trackAngle
        # Угол отклонения текущего положения шарика от метки
        error = (angleDiff + 180) % 360 - 180
        self.errors.append(error)

        newAccuracy = round(((180 - abs(error)) / 180) * 100, 2)
        self.accuracies.append(newAccuracy)
        self.connection.send(self.name + " " + str(newAccuracy))

        self.currentAccuracy = round(statistics.mean(self.accuracies), 3)

    # Обработка нажатия на привязанную к данному кругу кнопку
    def sharikClick(self):
        if not self.isClickLastLap:
            self.goodBeep()
            self.calculateAccuracy(self.sharikAngle)
        else:
            self.badBeep()

    # Метод с "хорошим" пищанием (издаётся при корректном нажатии кнопки)
    def goodBeep(self):
        self.goodTone.play()

    # Метод с "плохим" пищанием (издаётся при некорректном нажатии кнопки)
    def badBeep(self):
        self.badTone.play()

    # https://stackoverflow.com/questions/4183208/how-do-i-rotate-an-image-around-its-center-using-pygame
    def blitRotate(self, surf, image, pos, originPos, angle):
        # offset from pivot to center
        image_rect = image.get_rect(topleft=(pos[0] - originPos[0], pos[1] - originPos[1]))
        offset_center_to_pivot = pygame.math.Vector2(pos) - image_rect.center

        # rotated offset from pivot to center
        rotated_offset = offset_center_to_pivot.rotate(-angle)

        # rotated image center
        rotated_image_center = (pos[0] - rotated_offset.x, pos[1] - rotated_offset.y)

        # get a rotated image
        rotated_image = pygame.transform.rotate(image, angle)
        rotated_image_rect = rotated_image.get_rect(center=rotated_image_center)

        # rotate and blit the image
        surf.blit(rotated_image, rotated_image_rect)
