import multiprocessing
from multiprocessing import Pipe
import serial
import threading
import Game
from Arduino import Arduino

gsr = []
errors = []

if __name__ == '__main__':
    # arduino = Arduino()
    # Взаимодействие между процессами реализовано через пайп
    receiver, sender = Pipe()

    # arduino = threading.Thread(target=arduino.startDevice, args=(receiver,))
    gameProcess = multiprocessing.Process(target=Game.start, args=(sender,), daemon=True)

    # arduino.start()
    gameProcess.start()
    # arduino.join()
    gameProcess.join()

