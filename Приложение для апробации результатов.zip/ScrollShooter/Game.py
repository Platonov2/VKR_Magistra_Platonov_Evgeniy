import pygame

from views.Level import Level
from views.Menu import Menu
from views.Pause import Pause


def start(sender, receiver, sender2, receiver2):
    width = 1536
    height = 864
    screen = pygame.display.set_mode((width, height))
    pygame.init()

    menu = Menu(screen, width, height)
    level = Level(screen, width, height, sender, sender2)
    pauseWindow = Pause(screen, width, height)

    isMenu = True
    isLevel = False

    clock = pygame.time.Clock()
    running = True
    pause = True

    lastDifficult = 0

    while running:

        if receiver2.poll():
            message = receiver2.recv()
            if message == "restart":
                print(message)
                del level
                level = Level(screen, width, height, sender, sender2)

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
                sender.send("end")

            if isMenu and event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                sender.send("start")
                isMenu = False
                isLevel = True

        if isMenu:
            menu.draw()

        if isLevel:
            keys = pygame.key.get_pressed()
            level.keyHandler(keys)
            level.update()

        pygame.display.update()
        # Игра работает в 60 fps
        clock.tick(60)

    pygame.quit()
