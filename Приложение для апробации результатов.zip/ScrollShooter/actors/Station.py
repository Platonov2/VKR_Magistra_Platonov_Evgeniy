import pygame
from pygame import Vector2

from actors.Animation import Animation
from actors.IRoteted import IRotated


class Station(pygame.sprite.Sprite, IRotated):
    def __init__(self, screen, width, height):
        pygame.sprite.Sprite.__init__(self)
        IRotated.__init__(self, 0.5)

        image = pygame.image.load("images/base.png").convert_alpha()
        sourceSize = image.get_size()
        sizeMultiplier = 0.2
        self.rect = pygame.rect.Rect((0, 0), (sourceSize[0] * sizeMultiplier - 30, sourceSize[1] * sizeMultiplier - 30))
        self.image = pygame.transform.scale(image, (sourceSize[0] * sizeMultiplier, sourceSize[1] * sizeMultiplier))
        self.size = self.image.get_size()

        self.screen = screen

        self.rect.x = width // 2 - self.size[0] // 2
        self.rect.y = height // 2 - self.size[1] // 2

    def update(self):
        self.rotateTick()
        self.blitRotate(self.screen, self.image, self.rect.center,
                        (self.image.get_size()[0] / 2, self.image.get_size()[1] / 2), self.angle)
        # pygame.draw.rect(self.screen, (255, 255, 255), self.rect, 1)
