import pygame


class Animation(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, animationSet, sizeMultiplier, durationMultiplier):
        pygame.sprite.Sprite.__init__(self)

        self.screen = screen
        self.x = x
        self.y = y
        self.sizeMultiplier = sizeMultiplier

        self.animationSet = animationSet
        self.currentFrame = 0
        self.durationMultiplier = durationMultiplier

    def update(self):
        currentImage = self.animationSet[self.currentFrame // self.durationMultiplier]

        # Корректное выравнивание анимации
        sourceSize = currentImage.get_size()
        rect = pygame.rect.Rect((0, 0), (sourceSize[0] * self.sizeMultiplier + 30, sourceSize[1] * self.sizeMultiplier))
        currentImage = pygame.transform.scale(currentImage, (sourceSize[0] * self.sizeMultiplier, sourceSize[1] * self.sizeMultiplier))
        size = currentImage.get_size()
        rect.x = self.x
        rect.y = self.y

        self.screen.blit(currentImage, (rect.x - size[0], rect.y - size[1]))

        self.currentFrame += 1
        if self.currentFrame == len(self.animationSet) * self.durationMultiplier:
            self.kill()
