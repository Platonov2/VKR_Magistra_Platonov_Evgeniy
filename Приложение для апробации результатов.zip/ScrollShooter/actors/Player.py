import math
import pygame
from pgzero import tone

from actors.Animation import Animation
from actors.IRoteted import IRotated
from actors.Missile import Missile


class Player(pygame.sprite.Sprite, IRotated):
    def __init__(self, screen, width, height):
        pygame.sprite.Sprite.__init__(self)
        IRotated.__init__(self, 0.5)

        self.goodTone = tone.create('D5', 0.001)
        self.badTone = tone.create('D#1', 0.5)

        self.screen = screen
        self.width = width
        self.height = height

        image = pygame.image.load("./images/spaceship.png").convert_alpha()
        size = image.get_size()
        self.image = pygame.transform.scale(image, (size[0] * 0.2, size[1] * 0.2))
        self.rect = pygame.rect.Rect((0, 0), (45, 45))
        self.size = image.get_size()

        self.x = 100
        self.y = 100
        self.speed = 3

        self.isTop = False
        self.isRight = False
        self.isDown = False
        self.isLeft = False

        self.missiles = pygame.sprite.Group()
        self.reloadTime = 60
        self.currentReload = 0

        self.isAlive = True
        self.reviveTimer = 0
        self.reviveTime = 300  # 5с

        self.explosionSet = []
        for i in range(1, 14):
            self.explosionSet.append(pygame.image.load(f"images/explosion/{i}.png").convert_alpha())
        self.explosionSet[0].get_rect()

        self.attention = 0

    def update(self):

        if not self.isAlive:
            self.reviveTimer += 1
            if self.reviveTimer == self.reviveTime:
                self.isAlive = True
                self.reviveTimer = 0
                self.x = self.width // 2
                self.y = self.height // 2
        else:
            if self.currentReload < self.reloadTime:
                self.currentReload += 1

            mouseX, mouseY = pygame.mouse.get_pos()
            relX, relY = mouseX - self.x, mouseY - self.y
            angle = (180 / math.pi) * -math.atan2(relY, relX)
            self.angle = angle

            self.rect.x = self.x
            self.rect.y = self.y

            self.blitRotate(self.screen, self.image, self.rect.center,
                            (self.image.get_size()[0] / 2, self.image.get_size()[1] / 2), self.angle)
            # pygame.draw.rect(self.screen, (255, 255, 255), self.rect, 1)

    def keyHandler(self, keys):
        if self.isAlive:
            if keys[pygame.K_w]:
                self.y -= self.speed
                if self.y < 0:
                    self.y = 0
            if keys[pygame.K_d]:
                self.x += self.speed
                if self.x > self.width:
                    self.x = self.width
            if keys[pygame.K_s]:
                self.y += self.speed
                if self.y > self.height:
                    self.y = self.height
            if keys[pygame.K_a]:
                self.x -= self.speed
                if self.x < 0:
                    self.x = 0
            if keys[pygame.K_SPACE]:
                self.createMissile()

    def createMissile(self):
        if self.isAlive:
            if self.currentReload >= self.reloadTime:
                # print(self.reloadTime)
                self.goodBeep()
                mouseX, mouseY = pygame.mouse.get_pos()
                missile = Missile(self.rect.centerx, self.rect.centery, mouseX, mouseY, self.screen, self.width,
                                  self.height)
                self.missiles.add(missile)
                self.currentReload = 0

    def goodBeep(self):
        self.goodTone = tone.create('D5', 0.01)
        self.goodTone.play()

    def badBeep(self):
        self.badTone = tone.create('D#1', 0.5)
        self.badTone.play()

    def killScript(self):
        self.badBeep()
        self.isAlive = False
        self.rect.x = -100
        self.rect.y = -100
        return Animation(self.screen, self.rect.centerx + self.size[0] // 2, self.rect.centery + self.size[1] // 2,
                         self.explosionSet, 0.2, 4)
