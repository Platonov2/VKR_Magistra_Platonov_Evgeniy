import pygame
from pgzero import tone
from pygame import Vector2

from actors.Animation import Animation
from actors.IRoteted import IRotated


class Meteorite(pygame.sprite.Sprite, IRotated):
    def __init__(self, screen, startX, startY, width, height, difficult):
        pygame.sprite.Sprite.__init__(self)
        IRotated.__init__(self, 0.5)

        self.goodTone = tone.create('C#4', 0.001)
        self.badTone = tone.create('D#1', 0.5)

        image = pygame.image.load("images/meteorite.png").convert_alpha()
        sourceSize = image.get_size()
        sizeMultiplier = 0.1
        self.rect = pygame.rect.Rect((0, 0), (sourceSize[0] * sizeMultiplier - 12, sourceSize[1] * sizeMultiplier - 15))
        self.image = pygame.transform.scale(image, (sourceSize[0] * sizeMultiplier, sourceSize[1] * sizeMultiplier))
        self.size = self.image.get_size()

        self.screen = screen
        self.centreX = width // 2 - self.size[0] // 2
        self.centreY = height // 2 - self.size[1] // 2

        self.difficult = difficult

        self.x = startX
        self.y = startY
        self.speed = abs(self.centreX - startX) / (1500 - self.difficult)

        if self.centreX == startX:
            startX += 10
        self.a = (self.centreY - startY) / (self.centreX - startX)
        self.b = self.centreY - self.a * self.centreX
        self.y = self.a * self.x + self.b

        self.explosionSet = []
        for i in range(1, 14):
            self.explosionSet.append(pygame.image.load(f"images/explosion/{i}.png").convert_alpha())
        self.explosionSet[0].get_rect()

    def update(self):
        if self.x < self.centreX:
            self.x += self.speed
        else:
            self.x -= self.speed

        self.y = self.a * self.x + self.b

        self.rect.x = self.x
        self.rect.y = self.y

        self.rotateTick()
        self.blitRotate(self.screen, self.image, self.rect.center,
                        (self.image.get_size()[0] / 2, self.image.get_size()[1] / 2), self.angle)

    def goodBeep(self):
        self.goodTone.play()

    def badBeep(self):
        self.badTone.play()

    def killScript(self):
        self.kill()
        return Animation(self.screen, self.rect.centerx + self.size[0] // 2, self.rect.centery + self.size[1] // 2, self.explosionSet, 0.2, 4)
