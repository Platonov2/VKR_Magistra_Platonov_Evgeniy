import math

import pygame

from actors.Animation import Animation
from actors.IRoteted import IRotated


class Missile(pygame.sprite.Sprite, IRotated):
    def __init__(self, startX, startY, targetX, targetY, screen, width, height):
        pygame.sprite.Sprite.__init__(self)
        IRotated.__init__(self, 0)

        self.screen = screen
        self.width = width
        self.height = height

        image = pygame.image.load("images/missile.png").convert_alpha()
        self.animations = pygame.sprite.Group()

        sourceSize = image.get_size()
        sizeMultiplier = 0.03
        self.rect = pygame.rect.Rect((0, 0), (sourceSize[0] * sizeMultiplier - 50, sourceSize[1] * sizeMultiplier - 50))
        self.image = pygame.transform.scale(image, (sourceSize[0] * sizeMultiplier, sourceSize[1] * sizeMultiplier))
        self.size = self.image.get_size()
        self.rect.x = width // 2 - self.size[0] // 2
        self.rect.y = height // 2 - self.size[1] // 2

        self.startX = startX
        self.startY = startY
        self.targetX = targetX
        self.targetY = targetY

        self.speed = abs(targetX - startX) / 1500
        if targetX == startX:
            targetX += 1
        self.a = (targetY - startY) / (targetX - startX)
        self.b = targetY - self.a * targetX
        self.x = startX
        self.y = self.a * self.x + self.b

        self.speed = 10
        self.angle = (180 / math.pi) * -math.atan2(targetY - startY, targetX - startX)

    def update(self):
        # self.animations.update()
        self.blitRotate(self.screen, self.image, self.rect.center,
                        (self.image.get_size()[0] / 2, self.image.get_size()[1] / 2), self.angle)
        # if self.targetX - self.startX
        newX = self.x

        if self.startX < self.targetX:
            newX += self.speed
        else:
            newX -= self.speed

        newY = self.a * newX + self.b

        if abs(newY - self.y) > self.height // 100:
            if newY < self.y:
                self.x = ((self.y - self.height // 100) - self.b) / self.a
            else:
                self.x = ((self.y + self.height // 100) - self.b) / self.a
        else:
            self.x = newX

        self.y = self.a * self.x + self.b

        self.rect.x = self.x
        self.rect.y = self.y

        # Уничтожить, если заходит за верхнюю часть экрана
        if self.rect.right < 0 or self.rect.bottom < 0 or self.rect.left > self.width or self.rect.top > self.height:
            self.kill()

        # self.screen.blit(self.image, self.rect)
        # pygame.draw.rect(self.screen, (255, 255, 255), self.rect, 1)
