import pygame


class GameOverInterface:
    def __init__(self, screen, width, height):
        self.screen = screen
        self.width = width
        self.height = height

        self.font = pygame.font.SysFont(None, 48)

        self.score = 0

    def update(self):
        pygame.draw.rect(self.screen, pygame.Color("White"), (self.width // 2 - 400, self.height // 2 - 150, 800, 300))
        pygame.draw.rect(self.screen, pygame.Color("Black"), (self.width // 2 - 400, self.height // 2 - 150, 800, 300), width=5)

        text = self.font.render("База уничтожена", True, pygame.Color("Black"))
        text_rect = text.get_rect(center=(self.width // 2, self.height // 2 - 50))
        self.screen.blit(text, text_rect)

        string = "Счёт: " + str(self.score)
        text = self.font.render(string, True, pygame.Color("Black"))
        text_rect = text.get_rect(center=(self.width // 2, self.height // 2 + 50))
        self.screen.blit(text, text_rect)
