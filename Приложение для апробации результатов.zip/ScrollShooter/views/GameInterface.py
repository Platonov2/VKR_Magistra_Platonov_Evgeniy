import pygame


class GameInterface:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 48)
        self.score = 0
        self.currentReload = 0
        self.reloadTime = 0
        self.timerOffset = 0
        self.timerWidth = 100

    def update(self):
        string = "Перезарядка: " + str(self.reloadTime)
        text = self.font.render(string, True, (255, 255, 255))
        text_rect = text.get_rect(midleft=(44, 50))
        self.screen.blit(text, text_rect)

        pygame.draw.rect(self.screen, pygame.Color("White"), (330, 35, self.timerWidth, 25))

        time = self.currentReload / self.reloadTime * self.timerWidth

        if time > self.timerWidth:
            self.timerOffset = self.timerWidth
        else:
            self.timerOffset = time

        pygame.draw.rect(self.screen, pygame.Color("Blue"), (330, 35, self.timerOffset, 25))

        string = "Счёт: " + str(self.score)
        text = self.font.render(string, True, (255, 255, 255))
        text_rect = text.get_rect(center=(100, 100))
        self.screen.blit(text, text_rect)
