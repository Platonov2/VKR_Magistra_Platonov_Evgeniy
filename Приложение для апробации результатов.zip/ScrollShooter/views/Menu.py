import pygame

class Menu:
    def __init__(self, screen, width, height):
        self.screen = screen
        self.width = width
        self.height = height
        self.font = pygame.font.SysFont(None, 64)

    def draw(self):
        self.screen.fill((255, 255, 255))

        text = self.font.render("Пробел - Начать игру", True, (90, 90, 90))
        text_rect = text.get_rect(center=(self.width / 2, self.height * 0.8))
        self.screen.blit(text, text_rect)
