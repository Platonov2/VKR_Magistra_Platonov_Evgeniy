import random
import pygame

from actors.Gold import Gold
from actors.Station import Station
from actors.Meteorite import Meteorite
from actors.Player import Player
from views.GameInterface import GameInterface
from views.GameOverInterface import GameOverInterface


class Level:
    def __init__(self, screen, width, height, sender, sender2):
        self.alphaRhythm = 0
        self.screen = screen
        self.width = width
        self.height = height

        self.player = Player(screen, width, height)
        station = Station(screen, width, height)
        self.base = pygame.sprite.Group()
        self.base.add(station)
        self.meteorites = pygame.sprite.Group()
        self.golds = pygame.sprite.Group()
        self.animations = pygame.sprite.Group()

        self.background = pygame.image.load("images/space.jpg").convert()
        self.interface = GameInterface(screen)
        self.gameOverInterface = GameOverInterface(self.screen, self.width, self.height)

        self.meteorTimer = 0
        self.meteorSpawnTime = 100
        self.goldTimer = 0
        self.goldSpawnTime = 150
        self.difficult = 0
        self.difficultTimer = 0
        self.difficultGrowTime = 300

        self.sender = sender
        self.sender2 = sender2

        self.isGameOver = False

    def setAlphaRhythm(self, alpha):
        self.alphaRhythm = alpha

    def update(self):
        self.screen.blit(self.background, (0, 0))

        self.meteorTimer += 1
        self.goldTimer += 1
        self.difficultTimer += 1

        if self.difficultTimer == self.difficultGrowTime:
            self.difficultTimer = 0
            self.difficult += 0.5
            self.sender.send(self.difficult)

        if not self.isGameOver:
            if self.meteorTimer >= self.meteorSpawnTime - self.difficult:
                self.createMeteorite()
                self.meteorTimer = 0
            if self.goldTimer >= self.goldSpawnTime:
                self.createGold()
                self.goldTimer = 0

            self.interface.reloadTime = self.player.reloadTime
            self.interface.currentReload = self.player.currentReload
            self.interface.update()

        self.player.update()
        self.base.update()
        self.meteorites.update()
        self.golds.update()
        self.player.missiles.update()
        self.animations.update()

        self.handleCollision()

        # if self.isGameOver:
        #     self.gameOverInterface.update()

    def handleCollision(self):
        hitsPlayerMeteor = pygame.sprite.spritecollide(self.player, self.meteorites, False)
        for meteor in hitsPlayerMeteor:
            self.animations.add(meteor.killScript())
            self.player.killScript()
        hitsPlayerGold = pygame.sprite.spritecollide(self.player, self.golds, False)
        for gold in hitsPlayerGold:
            self.animations.add(gold.killScript())
            self.player.killScript()
        hitsMissilesMeteor = pygame.sprite.groupcollide(self.meteorites, self.player.missiles, False, True)
        for meteor in hitsMissilesMeteor:
            meteor.goodBeep()
            self.animations.add(meteor.killScript())
        hitsBaseMeteor = pygame.sprite.groupcollide(self.meteorites, self.base, True, True)
        for meteor in hitsBaseMeteor:
            meteor.badBeep()
            self.animations.add(meteor.killScript())
            # self.isGameOver = True
            self.difficult = 0
            self.sender2.send("restart")
            self.gameOverInterface.score = self.interface.score
        hitsMissileBase = pygame.sprite.groupcollide(self.player.missiles, self.base, True, False)
        hitsGoldBase = pygame.sprite.groupcollide(self.golds, self.base, True, False)
        for gold in hitsGoldBase:
            gold.goodBeep()
            self.animations.add(gold.killScript())
            self.interface.score += 1
        hitsGoldMissile = pygame.sprite.groupcollide(self.golds, self.player.missiles, False, True)
        for gold in hitsGoldMissile:
            gold.badBeep()
            self.animations.add(gold.killScript())

    def createMeteorite(self):
        sides = ['top', 'bottom', 'left', 'right']
        side = random.choice(sides)

        if side == "top":
            x = random.randint(0, self.width)
            y = 0 - 50
        elif side == "right":
            x = self.width + 50
            y = random.randint(0, self.height)
        elif side == "bottom":
            x = random.randint(0, self.width)
            y = self.height + 50
        elif side == "left":
            x = 0 - 50
            y = random.randint(0, self.height)

        self.meteorites.add(Meteorite(self.screen, x, y, self.width, self.height, self.difficult))

    def createGold(self):
        sides = ['top', 'bottom', 'left', 'right']
        side = random.choice(sides)

        if side == "top":
            x = random.randint(0, self.width)
            y = 0 - 50
        elif side == "right":
            x = self.width + 50
            y = random.randint(0, self.height)
        elif side == "bottom":
            x = random.randint(0, self.width)
            y = self.height + 50
        elif side == "left":
            x = 0 - 50
            y = random.randint(0, self.height)

        self.golds.add(Gold(self.screen, x, y, self.width, self.height, self.difficult))

    def keyHandler(self, event):
        if not self.isGameOver:
            self.player.keyHandler(event)
