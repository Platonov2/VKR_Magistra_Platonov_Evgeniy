import serial
import pandas
import time


# Класс для считывания данных с ардуино
class Arduino:
    def __init__(self):
        self.ecg = []
        self.fpg = []
        self.gsr = []

        self.leftErrors = []
        self.centreErrors = []
        self.rightErrors = []

        self.difficult = 0
        self.difficulties = []

        self.time = []

        self.ser = serial.Serial("COM9", 9600)
        self.isRecording = False

    def startDevice(self, pipeConnection):

        while True:

            if self.isRecording:
                data = self.ser.readline().decode("utf-8").split(" ")

                try:
                    ecg = data[0].split(":")[1]
                    fpg = data[1].split(":")[1]
                    gsr = data[2].split(":")[1]
                except:
                    print(data)
                    continue

                self.ecg.append(ecg)
                self.fpg.append(fpg)
                self.gsr.append(gsr)
                self.difficulties.append(self.difficult)
                # print(self.difficults)

                self.time.append(int(round(time.time() * 1000)))

            if pipeConnection.poll():
                message = pipeConnection.recv()

                if message == "start":
                    self.isRecording = True
                elif message == "end":
                    self.isRecording = False
                    dataFrame = pandas.DataFrame()

                    dataFrame["time"] = self.time
                    dataFrame["ecg"] = self.ecg
                    dataFrame["fpg"] = self.fpg
                    dataFrame["gsr"] = self.gsr
                    dataFrame["difficulties"] = self.difficulties

                    dataFrame.to_csv("data/last.csv")
                else:
                    self.difficult = message
                    # print(self.difficult)

    def startRecord(self):
        self.isRecording = True
