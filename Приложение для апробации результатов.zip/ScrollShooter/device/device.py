import serial
import pandas


# Класс для считывания данных с ардуино
class Device:
    def __init__(self):
        # self.isArduinoConnected = False
        self.ser = serial.Serial("COM12", 57600)

        self.payloadData = [i for i in range(32)]
        self.attentionList = []
        self.listLimit = 5

        self.isGameRunning = True

    def startDevice(self, sender, receiver):

        while self.isGameRunning:
            if receiver.poll():
                message = receiver.recv()
                if message == "Close":
                    self.isGameRunning = False

            if self.ser.read() == b'\xaa':
                if self.ser.read() == b'\xaa':
                    payloadLength = int.from_bytes(self.ser.read(),  byteorder='little')
                    # print(payloadLength)
                    if payloadLength > 169:
                        return

                    generatedChecksum = 0

                    for i in range(payloadLength):
                        self.payloadData[i] = int.from_bytes(self.ser.read(),  byteorder='little')
                        generatedChecksum += self.payloadData[i]

                    checksum = int.from_bytes(self.ser.read(),  byteorder='little')
                    generatedChecksum = 255 - generatedChecksum

                    # print(checksum)
                    # print(generatedChecksum)
                    # print()

                    if checksum == generatedChecksum:
                        # print("Да")
                        poorQuality = 200

                        for i in range(payloadLength):
                            data = self.payloadData[i]

                            if data == 4:
                                i += 1
                                meditation = self.payloadData[i]
                                self.attentionList.append(meditation)

                                if len(self.attentionList) == self.listLimit:
                                    # meanAttention = sum(self.attentionList) // len(self.attentionList)
                                    meanAttention = max(self.attentionList)
                                    print(meanAttention)
                                    sender.send(meanAttention)
                                    self.attentionList = []
