import multiprocessing
import os
import sys
from multiprocessing import Pipe
import threading

import Game
from device.Arduino import Arduino
from device.device import Device

if __name__ == '__main__':
    arduino = Arduino()
    # device = Device()
    # Взаимодействие между процессами реализовано через пайп
    receiver, sender = Pipe()
    receiver2, sender2 = Pipe()

    # print(os.getcwd())
    # print(os.path.dirname(os.path.abspath(__file__)))
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    # print(os.getcwd())

    arduino = threading.Thread(target=arduino.startDevice, args=(receiver,))
    gameProcess = multiprocessing.Process(target=Game.start, args=(sender, receiver2, sender2, receiver2,), daemon=True)

    arduino.start()
    gameProcess.start()
    arduino.join()
    gameProcess.join()
